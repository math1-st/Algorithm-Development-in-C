// Usamos o locale temporariamente na fun��o de curtir_descurtir para n�o gerar problemas com pontua��o.
#include <locale.h>
#include "funcoes.h"

void limpar_terminal() {
    // H� outras formas de limpar o terminal em C, mas essa usa ASCII e � mais f�cil, r�pido e universal em qualquer SO.
    // \e[1;1H move o cursors para a linha 1, coluna 1, para evitar problemas.
    // \e[2J limpa o terminal.
    printf("\033[H\033[2J");
}

void verificar_abertura_arquivo(FILE *arquivo)
{
    // Verifica��o r�pida de erro ao abrir arquivo.
    // Essa fun��o N�O fecha arquivos.
    if (arquivo == NULL)
    {
        printf("\nErro ao abrir arquivo. Trate o erro.");
        printf("Fechando o programa.\n");
        exit(0);
    }
}

int cadastrar_usuario()

    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */

{
    // Modo "a+" anexa e l� dados do arquivo.
    FILE *contas_usuarios = fopen("contas_usuarios.txt", "a+");
    verificar_abertura_arquivo(contas_usuarios);

    char criar_usuario[20], criar_senha[20];
    //Usa-se variaveis_comparacao porque fscanf() precisa atribuir cada elemento de uma linha em uma vari�vel para poder comparar.
    char usuario_comparacao[20], senha_comparacao[20];
    int id_comparacao, ultimo_id = -1, id_usuario;

    printf("\n�rea de Cadastro.\n");

    do
    {
        printf("\nDigite o seu usu�rio: ");
        scanf("%s", criar_usuario);

        rewind(contas_usuarios);

        // fscanf() consegue comparar diferentes tipos de dados. Aqui, tamb�m � essencial usar senha_comparacao,
        // pois fscanf() precisa identificar e guardar TODOS os lementos em uma linha, por precisa ser igual a 3.
        while(fscanf(contas_usuarios, "%d|%[^|]|%s", &id_comparacao, usuario_comparacao, senha_comparacao) == 3)
        {
            // Verifica se o usu�rio j� existe
            if (strcmp(usuario_comparacao, criar_usuario) == 0)
            {
                limpar_terminal();
                printf("\nEsse usu�rio j� existe. Tente outro.\n");
                fclose(contas_usuarios);
            }
        }

    } while (strcmp(usuario_comparacao, criar_usuario) == 0);

    // Rastreia o maior ID encontrado
    if (id_comparacao > ultimo_id) {
        ultimo_id = id_comparacao;
    }

    // Adiciona 1 ao maior ID. Esse � o ID do usu�rio cadastrado agora.
    id_usuario = ultimo_id + 1;

    printf("Digite a sua senha: ");
    scanf("%s", criar_senha);

    // Anexando dados ao arquivo em uma s� linha.
    fprintf(contas_usuarios, "%d|%s|%s\n", id_usuario, criar_usuario, criar_senha);

    // Fecha-se o arquivo contas_usuarios ap�s gravar suas informa��es.
    fclose(contas_usuarios);

    limpar_terminal();

    // ID do usuario ser� usado posteriormente para relacionar bancos de dados.
    return id_usuario;
}

int logar_usuario()

    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */

{
    FILE *contas_usuarios = fopen("contas_usuarios.txt", "r");
    verificar_abertura_arquivo(contas_usuarios);

    char usuario_de_login[20], senha_de_login[20];
    char usuario_comparacao[20], senha_comparacao[20];
    int id_comparacao, id_usuario = -1;

    printf("\n�rea de Login.\n");

    printf("\nUsu�rio: ");
    scanf("%s", usuario_de_login);

    printf("Senha: ");
    scanf("%s", senha_de_login);

    while(fscanf(contas_usuarios, "%d|%[^|]|%s", &id_comparacao, usuario_comparacao, senha_comparacao) == 3)
    {
        if (strcmp(usuario_de_login, usuario_comparacao) == 0 && strcmp(senha_de_login, senha_comparacao) == 0)
        {
            id_usuario = id_comparacao;
            break;
        }
    }

    fclose(contas_usuarios);

    if (id_usuario == -1) {printf("Usu�rio ou senha incorretos. Tente novamente.");}

    limpar_terminal();

    return id_usuario;
}

void ver_minha_area(int id_usuario, char categoria[])

    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */

{
    FILE *area_usuarios = fopen("area_usuarios.txt", "r");
    verificar_abertura_arquivo(area_usuarios);

    char id_usuario_comparar[128];
    // Transformando o ID do usuario em string para comparar com o ID do arquivo (que � uma string).
    // Aquele 'pipe' ap�s '%d' ajuda o programa a entender onde o ID termina, e n�o simplesmente ler '1' de '15' e achar que o ID � '1'.
    sprintf(id_usuario_comparar, "%d|", id_usuario);

    printf("\n[%s]\n", categoria);

    char caracteres_na_linha[256];
    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), area_usuarios))
    {
        if (strncmp(caracteres_na_linha, id_usuario_comparar, strlen(id_usuario_comparar)) == 0)
        {
            char *categoria_encontrada;
            char *obra_encontrada;
            char *id_usuario_encontrado;

            id_usuario_encontrado = strtok(caracteres_na_linha, "|");
            categoria_encontrada = strtok(NULL, "|");
            obra_encontrada = strtok(NULL, "|");

            if (strcmp(categoria_encontrada, categoria) == 0)
            {
                printf("%s", obra_encontrada);
            }
        }
    }
    fclose(area_usuarios);
}

void listar_filtrado(char *categoria_escolhida)
{
    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */

    FILE *feitv_catalogo = fopen("catalogo.txt", "r");
    verificar_abertura_arquivo(feitv_catalogo);

    printf("\n%-3s | %-30s | %-20s | %-4s | %-4s | %-5s\n", "ID", "NOME", "GENERO", "ANO", "NOTA", "LIKES");

    // Usamos categoria_encontrada para indicar ao programa QUAL header exibir, uma vez que a condi��o for verdadeira.
    char categoria_no_arquivo[50], caracteres_na_linha[206];
    // %49[^|] significa: leia at� 49 letras ou at� encontrar o s�mbolo '|'.
    while(fscanf(feitv_catalogo, "%49[^|]", categoria_no_arquivo) == 1)
    {
        // Terminado de ler as categorias, lemos o restante da linha.
        fgets(caracteres_na_linha, 206, feitv_catalogo);

        // caracteres_na_linha[1] serve para ler o que vem depois do primeiro pipe que separa categorias.
        if (strcmp(categoria_no_arquivo, categoria_escolhida) == 0)
        {
            // 2. Usamos o strtok para pegar cada campo individualmente.
            char *id_da_obra     = strtok(caracteres_na_linha, "|");
            char *nome_da_obra   = strtok(NULL, "|");
            char *genero_da_obra = strtok(NULL, "|");
            char *ano_da_obra    = strtok(NULL, "|");
            char *nota_da_obra   = strtok(NULL, "|");
            char *likes_da_obra  = strtok(NULL, "|\n");

            // 3. Imprime os campos com tamanho fixo para alinhar os pipes.
            // O sinal de menos (%) alinha o texto � esquerda.
            printf("%-3s | %-30s | %-20s | %-4s | %-4s | %-5s\n", id_da_obra, nome_da_obra, genero_da_obra, ano_da_obra, nota_da_obra, likes_da_obra);
        }
    }

    fclose(feitv_catalogo);
}

void transformar_em_minusculo(char *nome_da_obra)
    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */
{
    for (int i = 0; nome_da_obra[i]; i++) {nome_da_obra[i] = tolower(nome_da_obra[i]);}
}

void procurar_obra()
    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */
{
    FILE *feitv_catalogo = fopen("catalogo.txt", "r");
    verificar_abertura_arquivo(feitv_catalogo);

    char input_usuario[50], input_em_minusculo[50];
    int obras_encontradas = 0;

    printf("\nDigite o nome ou parte do nome da obra.\n");
    printf("\n-> ");

    scanf(" %[^\n]", input_usuario);

    strcpy(input_em_minusculo, input_usuario);
    transformar_em_minusculo(input_em_minusculo);

    char caracteres_na_linha[256];

    // Cabe�alho seguindo um padr�o de alinhamento para ficar visualmente agrad�vel.
    printf("\n%-15s | %-3s | %-30s | %-20s | %-4s | %-4s | %-5s\n", "CATEGORIA", "ID", "NOME", "GENERO", "ANO", "NOTA", "LIKES");

    while (fgets(caracteres_na_linha, sizeof(caracteres_na_linha), feitv_catalogo))
    {
        // Criamos uma c�pia para o strtok n�o alterar a string original durante a leitura
        char linha_auxiliar[256];
        strcpy(linha_auxiliar, caracteres_na_linha);

        // Fatiando a linha para poder guardar cada informa��o em uma vari�vel e poder printar.
        char *categoria_no_arquivo = strtok(linha_auxiliar, "|");
        char *id_da_obra           = strtok(NULL, "|");
        char *nome_da_obra         = strtok(NULL, "|");
        char *genero_da_obra       = strtok(NULL, "|");
        char *ano_da_obra          = strtok(NULL, "|");
        char *nota_da_obra         = strtok(NULL, "|");
        char *likes_da_obra        = strtok(NULL, "|\n");

        if (nome_da_obra != NULL)
        {
            char nome_em_minusculo[100];
            strcpy(nome_em_minusculo, nome_da_obra);
            transformar_em_minusculo(nome_em_minusculo);

            // Compara��o para busca parcial (case-insensitive)
            if (strstr(nome_em_minusculo, input_em_minusculo) != NULL)
            {
                // Impress�o usando as vari�veis padronizadas
                printf("%-15s | %-3s | %-30s | %-20s | %-4s | %-4s | %-5s\n", categoria_no_arquivo, id_da_obra, nome_da_obra, genero_da_obra, ano_da_obra, nota_da_obra, likes_da_obra);
                obras_encontradas++;
            }
        }
    }
    if (obras_encontradas == 0) {printf("\nNenhuma obra encontrada com o termo: '%s'\n", input_usuario);}
    else {printf("N�mero de obras encontradas: %d\n", obras_encontradas);}
}

void curtir_obra(int id_do_usuario, int id_da_obra_selecionada, int curtir)
    /*

    FAZER DOC_STRING COM SUAS PR�PRIAS PALAVRAS.

    */
{
    // Como a l�ngua portuguesa usa v�rgula ao inv�s de ponto em decimais,
    // usamos o m�todo abaixo, temporariamente, para n�o confudir a l�gica.
    setlocale(LC_NUMERIC, "C");

    FILE *area_usuarios = fopen("area_usuarios.txt", "r");
    verificar_abertura_arquivo(area_usuarios);

    int id_obra_lida, id_usuario_lido, like_encontrado;

    char caracteres_na_linha[256];
    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), area_usuarios))
    {
        if (sscanf(caracteres_na_linha, "%d|LIKE|%d", &id_usuario_lido, &id_obra_lida) == 2)
        {
            if (id_usuario_lido == id_do_usuario && id_obra_lida == id_da_obra_selecionada)
            {
                like_encontrado = 1;
                break;
            }
        }
    }

    fclose(area_usuarios);

    if (like_encontrado)
    {
        if (curtir == 1)
        {
            printf("\nVoc� j� curtiu essa obra antes!\n");
            // Podemos usar return mesmo que a fun��o seja void, como forma de controle de fluxo.
            return;
        }
        else if (curtir == -1)
        {
            // Descurtir: Copia tudo exceto a linha do like.
            area_usuarios = fopen("area_usuarios.txt", "r");
            FILE *temporario = fopen("temporario.txt", "w");

            while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), area_usuarios))
            {
                if (sscanf(caracteres_na_linha, "%d|LIKE|%d", &id_usuario_lido, &id_obra_lida) == 2)
                {
                    // Se N�O for a linha que queremos remover, a gente copia
                    if (!(id_usuario_lido == id_do_usuario && id_obra_lida == id_da_obra_selecionada))
                    {
                        fprintf(temporario, "%s", caracteres_na_linha);
                    }
                }
            }

            fclose(area_usuarios);
            fclose(temporario);

            if (remove("area_usuarios.txt") == 0 && rename("temporario.txt", "area_usuarios.txt") == 0)
            {
                printf("\nVoc� descurtiu a obra.\n");
            }
            else
            {
                printf("\nHouve um erro ao remover a curtida:");
                printf("\nN�o foi poss�vel remover o arquivo E/OU:");
                printf("\nN�o foi poss�vel renomear o arquivo.\n");
            }
            return;
        }
    }
    else if (!like_encontrado && curtir == -1)
    {
        printf("\nVoc� precisa curtir a obra antes para poder descurtir.\n");
        return;
    }

    fclose(area_usuarios);

    FILE *catalogo = fopen("catalogo.txt", "r");
    verificar_abertura_arquivo(catalogo);

    FILE *temporario = fopen("temporario.txt", "w");
    verificar_abertura_arquivo(temporario);

    char linha_auxiliar[256];
    int ano_da_obra_lida, likes_da_obra_lida;
    float nota_da_obra_lida = 0.0;
    char categoria_lida[50], nome_da_obra_lida[50], genero_da_obra_lida[50];

    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), catalogo))
    {
        if (sscanf(caracteres_na_linha, "%[^|]|%d|%[^|]|%[^|]|%d|%f|%d",
        // Lembrando que strings n�o precisam de '&'.
        categoria_lida,
        &id_obra_lida,
        nome_da_obra_lida,
        genero_da_obra_lida,
        &ano_da_obra_lida,
        &nota_da_obra_lida,
        // Criando uma condi��o que l� categorias e o ID, ao mesmo tempo que coloca as informa��es em vari�veis.
        &likes_da_obra_lida) >= 2)
        {
            if (id_obra_lida == id_da_obra_selecionada)
            {
                if (curtir == 1) {likes_da_obra_lida++;}
                else if (curtir == -1) {likes_da_obra_lida--;}

                // Nesse fprintf(), colocamos em temporario a string de acordo com a ordem das vari�veis.
                fprintf(temporario, "%s|%d|%s|%s|%d|%.1f|%d\n",
                        categoria_lida, id_obra_lida, nome_da_obra_lida,
                        genero_da_obra_lida, ano_da_obra_lida,
                        nota_da_obra_lida, likes_da_obra_lida);
            }
            else
            {
                // Se n�o � a linha do ID que procuramos, apenas copiar para o arquivo tempor�rio.
                fprintf(temporario, "%s", caracteres_na_linha);
            }
        }
    }

    fclose(temporario);
    fclose(catalogo);

    if (remove("catalogo.txt") == 0 && rename("temporario.txt", "catalogo.txt") == 0)
    {
        // Por fim, registramos o like do usu�rio na �rea de usu�rios.
        area_usuarios = fopen("area_usuarios.txt", "a");
        verificar_abertura_arquivo(area_usuarios);

        fprintf(area_usuarios, "%d|LIKE|%d\n", id_do_usuario, id_da_obra_selecionada);
        fclose(area_usuarios);

        printf("\nVoc� curtiu a obra e em breve mais obras relacionadas ir�o aparecer para voc�!\n");
    }
    else
    {
        printf("\nHouve um erro ao salvar a curtida:");
        printf("\nN�o foi poss�vel remover o arquivo E/OU:");
        printf("\nN�o foi poss�vel renomear o arquivo.\n");
    }
}
