#include "funcoes.h"

void limpar_terminal() {
    // H� outras formas de limpar o terminal em C, mas essa usa ASCII e � mais f�cil e r�pido e permite qualquer SO.
    // \e[1;1H move o cursors para a linha 1, coluna 1, para evitar problemas.
    // \e[2J limpa o terminal.
    printf("\033[H\033[2J");
}

void verificar_abertura_arquivo(FILE *arquivo)
{
    // Verifica��o r�pida de erro ao abrir arquivo.
    // Essa fun��o N�O fecha arquivos.
    if (arquivo == NULL)
    {
        printf("\nErro ao abrir arquivo. Trate o erro.");
        printf("Fechando o programa.\n");
        exit(0);
    }
}

int cadastrar_usuario()
{
    // Modo "a+" anexa e l� dados do arquivo.
    FILE *contas_usuarios = fopen("contas_usuarios.txt", "a+");
    verificar_abertura_arquivo(contas_usuarios);

    char criar_usuario[20], criar_senha[20];
    //Usa-se variaveis_comparacao porque fscanf() precisa atribuir cada elemento de uma linha em uma vari�vel para poder comparar.
    char usuario_comparacao[20], senha_comparacao[20];
    int id_comparacao, ultimo_id = -1, id_usuario;

    printf("\n�rea de Cadastro.\n");

    printf("\nDigite o seu usu�rio: ");
    scanf("%s", criar_usuario);

    rewind(contas_usuarios);

    // fscanf() consegue comparar diferentes tipos de dados. Aqui, tamb�m � essencial usar senha_comparacao,
    // pois fscanf() precisa identificar TODOS os lementos em uma linha.
    while(fscanf(contas_usuarios, "%d %s %s", &id_comparacao, usuario_comparacao, senha_comparacao) != EOF)
    {
        // Verifica se o usu�rio j� existe
        if (strcmp(usuario_comparacao, criar_usuario) == 0)
        {
            printf("\nEsse usu�rio j� existe... Digite outro!\n");
            fclose(contas_usuarios);
            return -1; // Retorna erro
        }

        // Rastreia o maior ID encontrado
        if (id_comparacao > ultimo_id) {
            ultimo_id = id_comparacao;
        }
    }

    // Adiciona 1 ao maior ID. Esse � o ID do usu�rio cadastrado agora.
    id_usuario = ultimo_id + 1;

    printf("Digite a sua senha: ");
    scanf("%s", criar_senha);

    // Anexando dados ao arquivo em uma s� linha.
    fprintf(contas_usuarios, "%d " "%s " "%s\n", id_usuario, criar_usuario, criar_senha);

    // Fecha-se o arquivo contas_usuarios ap�s gravar suas informa��es.
    fclose(contas_usuarios);

    limpar_terminal();
    printf("\nConta criada com sucesso!\n");

    // ID do usuario ser� usado posteriormente para relacionar bancos de dados.
    return id_usuario;
}

int logar_usuario()
{
    FILE *contas_usuarios = fopen("contas_usuarios.txt", "r");
    verificar_abertura_arquivo(contas_usuarios);

    char usuario_de_login[20], senha_de_login[20];
    char usuario_comparacao[20], senha_comparacao[20];
    int id_comparacao, id_usuario = -1;

    printf("\n�rea de Login.\n");

    printf("\nUsu�rio: ");
    scanf("%s", usuario_de_login);

    printf("Senha: ");
    scanf("%s", senha_de_login);

    while(fscanf(contas_usuarios, "%d %s %s", &id_comparacao, usuario_comparacao, senha_comparacao) != EOF)
    {
        if (strcmp(usuario_de_login, usuario_comparacao) == 0 && strcmp(senha_de_login, senha_comparacao) == 0)
        {
            id_usuario = id_comparacao;
            break;
        }
    }

    fclose(contas_usuarios);

    if (id_usuario == -1) {printf("Usu�rio ou senha incorretos. Tente novamente.");}
    else {limpar_terminal();}

    return id_usuario;
}

void listar_filtrado(char categoria_escolhida)
{
    FILE *feitv_catalogo = fopen("catalogo.txt", "r");
    verificar_abertura_arquivo(feitv_catalogo);

    // Usamos categoria_encontrada para indicar ao programa QUAL header exibir, uma vez que a condi��o for verdadeira.
    int categoria_encontrada = 0;
    char caracteres_na_linha[256];
    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), feitv_catalogo))
    {
        // Verifica se a primeira informa��o na linha for um n�mero entre 1 e 7 e diferente de "[".
        if (caracteres_na_linha[0] >= '1' && caracteres_na_linha[0] <= '7' && strstr(caracteres_na_linha, "["))
        {
            // Se a primeira informa��o na linha for igual ao n�mero da categoria que o usu�rio escolheu, categoria_encontrada = 1.
            if (caracteres_na_linha[0] == categoria_escolhida)
            {
                categoria_encontrada = 1;
                printf("%-3s | %-35s | %-20s\n", "ID", "T�TULO", "G�NERO");
                continue;
            }
            else {categoria_encontrada = 0;}
        }

        /*
        strtok() ignora espa�os e pipes, lendo somente letras.
        Associamos vari�veis � ordem de informa��o lida na linha.
        Usamos caracteres_na_linha como primeiro argumento do id_da_obra porque est� sinalizando ONDE COME�AR a dividir a linha,
        enquanto que os outros chars usam NULL pra sinalizar COME�AR DE ONDE o strtok() ANTERIOR PAROU.
        */

        if (categoria_encontrada == 1)
        {
            //  Pule a linha se for uma quebra de linha ou uma linha muito curta.
            if (caracteres_na_linha[0] == '\n' || caracteres_na_linha[0] == '\r') continue;

            char *id_da_obra = strtok(caracteres_na_linha, "|");
            char *titulo_da_obra = strtok(NULL, "|");
            char *genero_da_obra = strtok(NULL, "|");

            // Como forma de seguran�a, o programa exibe se somente encontrar o id e o t�tulo.
            if (id_da_obra && titulo_da_obra) {printf("%s | %-30s | %-20s\n", id_da_obra, titulo_da_obra, genero_da_obra);}
        }
    }
    fclose(feitv_catalogo);
}

void ver_minha_area(int id_usuario, char categoria[])
{
    FILE *area_usuarios = fopen("area_usuarios.txt", "r");
    verificar_abertura_arquivo(area_usuarios);

    char id_usuario_comparar[128];
    // Transformando o ID do usuario em string para comparar com o ID do arquivo (que � uma string).
    // Aquele 'pipe' ap�s '%d' ajuda o programa a entender onde o ID termina, e n�o simplesmente ler '1' de '15' e achar que o ID � '1'.
    sprintf(id_usuario_comparar, "%d|", id_usuario);

    printf("\n[%s]\n", categoria);

    char caracteres_na_linha[256];
    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), area_usuarios))
    {
        if (strncmp(caracteres_na_linha, id_usuario_comparar, strlen(id_usuario_comparar)) == 0)
        {
            char *categoria_encontrada;
            char *obra_encontrada;
            char *id_usuario_encontrado;

            id_usuario_encontrado = strtok(caracteres_na_linha, "|");
            categoria_encontrada = strtok(NULL, "|");
            obra_encontrada = strtok(NULL, "|");

            if (strcmp(categoria_encontrada, categoria) == 0)
            {
                printf("%s", obra_encontrada);
            }
        }
    }

    fclose(area_usuarios);
}
