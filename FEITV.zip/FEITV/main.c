#include <stdio.h>
#include <stdlib.h>
// Biblioteca que permite a manipula��o de strings de arquivos externos.
#include <string.h>
// Biblioteca para for�ar o terminal a usar caraceteres em Portugu�s.
// OBS: n�o � poss�vel for�ar a leitura de caracteres da l�ngua portuguesa no arquivo .txt. Por isso, o arquivo n�o cont�m caracteres espec�ficos.
#include <locale.h>
// Chamada de arquivo de cabe�alho.
#include "funcoes.h"

// PERGUNTAR SOBRE PLAGIO: ALGUMAS ESTRUTURAS PODEM SER PENSADAS DE FORMA IGUAL!

/*
FEITO:
- BOAS VINDAS
- CADASTRO
- LOGIN
- LISTAR CATEGORIA
- MOSTRAR AREA DO USUARIO
- BUSCAR FILME/SERIE PELO NOME + LISTAR INFORMACOES DO FILME/SERIE ENCONTRADA
- COLOCAR OPCAO DE ASSISTIR + MOVER FILME/SERIE PARA ASSISTIDOS AO ASSISTIR OU DE PARAR DE ASSISTIR NO MEIO (vai para continuar assistindo)
- COLOCAR OPCAO DE CURTIR + PRINTAR 'FILMES/SERIES RELACIONADAS IR�O APARECER PARA VOC�'

O QUE FAZER:
- ADICIONAR LA�O DE REPETI��O PARA QUANDO USUARIO ERRAR O SCANF.
- ADICIONAR ESTRUTURA 'LIKES' NO .TXT E ARRUMAR AS FUN��ES DO PROGRAMA.

- COLOCAR OPCAO DE FAVORITAR E REMOVER FILMES/SERIE DA LISTA DE FAVORITO.
*/

// Asterisco ap�s char para sinalizar que quero retornar uma string.
char* procurar_obra()
{
    char nome_da_obra[30];
    int id_da_obra;

    FILE *feitv_catalogo = fopen("catalogo.txt", "r");
    verificar_abertura_arquivo(feitv_catalogo);

    printf("\nInsira o nome da obra ou parte do nome: ");
    // Como nome de obras podem conter espa�o, a estrutura abaixo permite inserir nomes com espa�os e serem verificados no loop em seguida.
    scanf(" %[^\n]", nome_da_obra);

    // Transforma a entrada do usu�rio em min�sculo.
    // Condi��o do meio no for: toda letra � true em C. Ao final do array, encontra-se "\0", que � false, ou seja, termina a condi��o.
    for (int i = 0; nome_da_obra[i]; i++) {
        nome_da_obra[i] = tolower(nome_da_obra[i]);
    }

    printf("\nResultado da busca:\n");

    char caracteres_na_linha[256];
    char transformar_em_minusculo[256];
    while (fgets(caracteres_na_linha, sizeof(caracteres_na_linha), feitv_catalogo))
    {
        // Vari�vel usada para armazenar aquilo que n�o interessa numa linha.
        int pular_header;
        if (sscanf(caracteres_na_linha, "%d [", &pular_header) == 2) {continue;}

        caracteres_na_linha[strcspn(caracteres_na_linha, "\n")] = 0;

        // Copiar a linha original para a auxiliar
        strcpy(transformar_em_minusculo, caracteres_na_linha);

        // Transformar a c�pia em min�sculo (letra por letra)
        for (int i = 0; transformar_em_minusculo[i]; i++) {
            transformar_em_minusculo[i] = tolower(transformar_em_minusculo[i]);
        }

        if (strstr(transformar_em_minusculo, nome_da_obra) != NULL)
        {
            printf("%s\n", caracteres_na_linha);
        }
    }

    printf("\nSelecione a obra pelo ID: ");
    scanf(" %d", &id_da_obra);

    if (id_da_obra < 1 || id_da_obra > 90) {printf("Voc� n�o selecionou uma obra corretamente. Tente novamente.");}

    int id_na_linha;
    while(fgets(caracteres_na_linha, sizeof(caracteres_na_linha), feitv_catalogo))
    {
        if (sscanf(caracteres_na_linha, "%d", &id_na_linha) == 1)
        {
            if (id_na_linha == id_da_obra)
            {
                strcpy(obra_selecionada, caracteres_na_linha);
                break;
            }
        }
    }

    fclose(feitv_catalogo);

    return obra_selecionada;
}

void assistir_favoritar_curtir(int id_usuario, char *obra_selecionada)
{
    char opcao;
    FILE *area_usuarios = fopen("area_usuarios.txt", "a+");
    verificar_abertura_arquivo(area_usuarios);

    printf("\nObra selecionada. O que deseja fazer?\n");
    printf("\n[1] Assistir a Obra");
    printf("\n[2] Adicion�-la � lista de desejos.");
    printf("\n[3] Adicionar aos Meus Favoritos");
    printf("\n[4] Curtir a Obra");
    printf("\n\n-> ");
    scanf(" %c", &opcao);


    switch (opcao)
    {
        case '1':

            fprintf(area_usuarios, "%d|ASSISTIDOS|%s\n", id_usuario, obra_selecionada);
            printf("\nOba! Mais uma obra adicionada � lista de assistidos.\n");
            break;

        case '2':

            fprintf(area_usuarios, "%d|LISTA DE DESEJOS|%s\n", id_usuario, obra_selecionada);
            printf("\nVoc� adicionou a obra � lista de desejos.\n");

            break;

        case '3':

            fprintf(area_usuarios, "%d|MEUS FAVORITOS|%s\n", id_usuario, obra_selecionada);
            printf("\nVoc� adicionou a obra � lista de favoritos.\n");
            break;

        case '4':

            // Transforma o ID em string.
            sprintf(id_string, "%d|", id_usuario);
            // � necess�rio usar o rewind, pois o modo "a+" l� at� o final e n�o volta.
            rewind(area_usuarios);

            int ja_curtiu;
            char caracteres_na_linha[256];
            while (fgets(caracteres_na_linha, sizeof(caracteres_na_linha), area_usuarios) == 0)
                {
                    // 'strstr() verifica se uma string existe, exatamente como descrita no seu argumento.
                    if
                        (strstr(caracteres_na_linha, id_usuario) != NULL && strstr(caracteres_na_linha, "CURTIU") != NULL && strstr(caracteres_na_linha, obra_selecionada) != NULL)
                    {
                        ja_curtiu = 1;
                        break;
                    }
                }
            if (ja_curtiu) {printf("\nVoc� j� curtiu a obra.\n");}
            else
            {
                fprintf(area_usuarios, "%d|CURTIU|%s\n", id_usuario, obra_selecionada);

                FILE *catalogo = fopen("catalogo.txt", "r");
                verificar_abertura_arquivo(catalogo);

                FILE *temporario = fopen("temporario.txt", "w");
                verificar_abertura_arquivo(temporario);

                char caracteres_na_linha2[256];
                int id, ano, curtidas;
                char nome_obra[30], genero_obra[30], nota[2];

                while (fgets(caracteres_na_linha2, sizeof(caracteres_na_linha2), catalogo) == 0)
                {

                 if (sscanf(caracteres_na_linha2, "%d | %[^|] %[^|] %[^|] | %d | %d", &id, nome_obra, genero_obra, ano, nota, &curtidas) == 6)
                 {
                     if (id==)
                 }

                }

                fclose(catalogo);
                fclose(temporario);

                remove("catalogo.txt");
                rename("temporario.txt", "catalogo.txt");

                printf("\nVoc� curtiu a obra. Iremos recomendar mais obras relacionadas.\n");
            }
            break;
    }
    fclose(area_usuarios);
}

int main(int argc, char *argv[])
{
    // For�ando o terminal a ler caracteres em portugu�s.
    setlocale(LC_ALL, "Portuguese");

    int id_usuario, id_da_obra;
    char opcao;

	printf("Bem-vindo ao FEItv!\n");
	printf("\nEscolha uma das opcoes abaixo:");
	printf("\n[1] Cadastrar-se");
	printf("\n[2] Login");
	printf("\n\n-> ");
    scanf(" %c", &opcao);

    // Consome espa�o extras do scanf.
    getchar();

    limpar_terminal();

    switch(opcao)
    {
        case '1':
            id_usuario = cadastrar_usuario();
            break;

        case '2':
            id_usuario = logar_usuario();
            printf("\nVoc� logou com sucesso!\n");
            break;

        default:
            printf("\nOp��o invalida. Tente novamente.\n");
            break;
    }

    printf("\nO que deseja fazer?\n");
    printf("\n[1] Ver Minha �rea");
    printf("\n[2] Listar Categorias");
    printf("\n[3] Procurar Uma Obra");
    printf("\n[4] Sair");
    printf("\n\n-> ");
    scanf(" %c", &opcao);

    limpar_terminal();

    // Baseado no que o usu�rio pediu, listar� coisas diferentes.
    switch (opcao)
    {
        case '1':
            // Ver Continuar Assistindo, Assistidos, Meus Favoritos.
            ver_minha_area(id_usuario, "ASSISTIR");
            ver_minha_area(id_usuario, "ASSISTIDOS");
            ver_minha_area(id_usuario, "MEUS FAVORITOS");
            break;

        case '2':
            // Listar Categorias para assistir.

            printf("\nO que vamos assistir?\n");
            printf("\n[1] Destaque");
            printf("\n[2] Top Anima��es");
            printf("\n[3] Top A��o");
            printf("\n[4] Top Drama");
            printf("\n[5] Top Esportes");
            printf("\n[6] Top 10 no Brasil");
            printf("\n[7] Document�rios");
            printf("\n-> ");
            scanf(" %c", &opcao);

            char obra_selecionada[256] = listar_filtrado(opcao);
            break;

        case '3':
            char obra_selecionada[256] = procurar_obra();
            break;

        case '4':
            // Sai do programa.
            exit(0);

        default:
            printf("\nOpcao invalida. Tente novamente.\n");
            break;
    }

    assistir_favoritar_curtir(id_usuario, obra_selecionada);

	return 0;
}

/*



*/
