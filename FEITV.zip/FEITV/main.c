#include <stdio.h>
#include <stdlib.h>
// Biblioteca que permite a manipula��o de strings de arquivos externos.
#include <string.h>
// Biblioteca para for�ar o terminal a usar caraceteres em Portugu�s.
// OBS: n�o � poss�vel for�ar a leitura de caracteres da l�ngua portuguesa no arquivo .txt. Por isso, o arquivo n�o cont�m caracteres espec�ficos.
#include <locale.h>
// Biblioteca para transformar letras mai�sculas em min�sculas. (Usada na fun��o procurar_obra())
#include <ctype.h>
// Chamada de arquivo de cabe�alho.
#include "funcoes.h"

// PERGUNTAR SOBRE PLAGIO: ALGUMAS ESTRUTURAS PODEM SER PENSADAS DE FORMA IGUAL!
// PERGUNTAR SE PROF QUER LISTA DE FAVORITOS PERSONALIZADA OU GERAL
// PERGUNTAR SE PRECISA EVITAR USU�RIO DIGITAR TEXTO NO SCANF

/*
O QUE FAZER:
- DOCSTRING PARA TODAS AS FUN��ES.
- COLOCAR OPCAO DE FAVORITAR E REMOVER FILMES/SERIE DA LISTA DE FAVORITO.
*/

int main(int argc, char *argv[])
{
    // For�ando o terminal a ler caracteres em portugu�s.
    setlocale(LC_ALL, "Portuguese");

    int opcao, id_usuario, id_da_obra;

    printf("Bem-vindo ao FEI TV!\n");

    do
    {
        printf("\nEscolha uma das opc�es abaixo:");
        printf("\n[1] Cadastrar-se");
        printf("\n[2] Login");
        printf("\n\n-> ");

        scanf("%d", &opcao);
        limpar_terminal();

        switch(opcao)
        {
            case 1:
                id_usuario = cadastrar_usuario();
                printf("\nConta criada com sucesso!\n");
                break;

            case 2:
                id_usuario = logar_usuario();
                printf("\nVoc� logou com sucesso!\n");
                break;

            default:
                printf("\nOp��o invalida. Tente novamente.\n");
                break;
        }

    } while (opcao != 1 && opcao != 2);

    do
    {
        printf("\nO que deseja fazer?\n");
        printf("\n[0] Voltar");
        printf("\n[1] Ver Minha �rea");
        printf("\n[2] Listar Categorias");
        printf("\n[3] Procurar Uma Obra");
        printf("\n\n-> ");

        scanf("%d", &opcao);

        limpar_terminal();

        int subopcao;

        // Baseado no que o usu�rio pediu, listar� coisas diferentes.
        switch (opcao)
        {
            case 0:
                break;
            case 1:
                // Ver Continuar Assistindo, Assistidos, Meus Favoritos.
                ver_minha_area(id_usuario, "ASSISTIR");
                ver_minha_area(id_usuario, "ASSISTIDOS");
                ver_minha_area(id_usuario, "MEUS FAVORITOS");
                break;

            case 2:
                // Listar Categorias para assistir.
                printf("\nQual categoria voc� quer acessar?\n");
                printf("\n[0] Voltar");
                printf("\n[1] Destaque");
                printf("\n[2] Top Anima��es");
                printf("\n[3] Top A��o");
                printf("\n[4] Top Drama");
                printf("\n[5] Top Esportes");
                printf("\n[6] Top 10 no Brasil");
                printf("\n[7] Document�rios");
                printf("\n\n-> ");

                scanf("%d", &subopcao);
                limpar_terminal();

                switch (subopcao)
                {
                    case 0:
                        break;
                    case 1:
                        listar_filtrado("DESTAQUE");
                        break;
                    case 2:
                        listar_filtrado("TOP ANIMACOES");
                        break;
                    case 3:
                        listar_filtrado("TOP ACAO");
                        break;
                    case 4:
                        listar_filtrado("TOP DRAMA");
                        break;
                    case 5:
                        listar_filtrado("TOP ESPORTES");
                        break;
                    case 6:
                        listar_filtrado("TOP 10 NO BRASIL");
                        break;
                    case 7:
                        listar_filtrado("DOCUMENTARIOS");
                        break;
                    default:
                        limpar_terminal();
                        printf("\nOp��o inv�lida. Tente novamente.\n");
                        break;
                }

                break;

            case 3:
                procurar_obra();
                // COLOCAR AQUI OUTRAS OP��ES AL�M DE CURTIR.
                do
                {
                    printf("\nDigite o ID da obra caso deseja selecionar alguma, ou zero para voltar.\n");
                    printf("\n-> ");

                    scanf("%d", &id_da_obra);

                    if (id_da_obra == 0) {break;}
                    else if (id_da_obra > 0 && id_da_obra < 100)
                    {
                        curtir_obra(id_usuario, id_da_obra);
                        break;
                    }
                    else  {printf("\nVoc� n�o selecionou um ID corretamente.\n");}

                } while (id_da_obra);

                break;

            default:
                printf("\nOp��o inv�lida. Tente novamente.\n");
                break;
        }

    } while (opcao != 0);

	return 0;
}
