#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

#include <stdio.h>

void limpar_terminal();
void inicializar_arquivo_de_contas();
void verificar_abertura_arquivo(FILE *arquivo);

#endif // FUNCOES_H_INCLUDED
